<?php

class ReflectionHelper extends CIPHPUnitTestReflection
{
}
